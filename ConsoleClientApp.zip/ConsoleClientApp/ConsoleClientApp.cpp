// ConsoleClientApp.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#import "SimpleATLCOMServer.dll" raw_interfaces_only
using namespace SimpleATLCOMServerLib;

//#import "SimpleATLCOMServerNew.dll" raw_interfaces_only
//using namespace SimpleATLCOMServerNewLib;

#include "TEventHandler.h"
using namespace TEventHandlerNamespace;

class EventHandler;

typedef TEventHandler<EventHandler, ISimpleCOMClass, _ISimpleCOMClassEvents> ISimpleCOMClassEventHandler;

class EventHandler
{
public :
	EventHandler(ISimpleCOMClassPtr spISimpleCOMClass)
	{
		// ***** Create an instance of an object which implements IEventFiringObject. *****
		m_spISimpleCOMClass = spISimpleCOMClass;

		// ***** Instantiate an IEventFiringObjectEventHandler object. *****
		m_pISimpleCOMClassEventHandler = new ISimpleCOMClassEventHandler(*this, m_spISimpleCOMClass, &EventHandler::OnSimpleCOMClassInvoke);
	}

	~EventHandler()
	{
		if (m_pISimpleCOMClassEventHandler)
		{
			m_pISimpleCOMClassEventHandler->ShutdownConnectionPoint();
			m_pISimpleCOMClassEventHandler->Release();
			m_pISimpleCOMClassEventHandler = NULL;
		}

		if (m_spISimpleCOMClass)
		{
			m_spISimpleCOMClass = NULL;
		}
	}

	ISimpleCOMClassPtr			m_spISimpleCOMClass;

	// ***** Declare a pointer to a TEventHandler class which is specially tailored *****
	// ***** to receiving events from the _IEventFiringObjectEvents events of an *****
	// ***** IEventFiringObject object. *****
	ISimpleCOMClassEventHandler* m_pISimpleCOMClassEventHandler;

	HRESULT EventHandler::OnSimpleCOMClassInvoke
		(
			ISimpleCOMClassEventHandler* pEventHandler,
			DISPID dispidMember,
			REFIID riid,
			LCID lcid,
			WORD wFlags,
			DISPPARAMS* pdispparams,
			VARIANT* pvarResult,
			EXCEPINFO* pexcepinfo,
			UINT* puArgErr
			)
	{
		if (dispidMember == 0x01)  // Event1 event.
		{
			// 1st param : [in] BSTR strParam.
			VARIANT	varValue;			

			VariantInit(&varValue);

			varValue = (pdispparams->rgvarg)[0];

			_bstr_t _bst(V_BSTR(&varValue), true);

			char szMessage[256];

			sprintf_s(szMessage, sizeof(szMessage), "Event 1 is fired with value : %s.", (LPCTSTR)_bst);

			::MessageBox(NULL, szMessage, "Event", MB_OK);
		}

		return S_OK;
	}
};

void DoTest()
{
	ISimpleCOMClassPtr spISimpleCOMClass = NULL;	

	spISimpleCOMClass.CreateInstance(__uuidof(SimpleCOMClass));

	EventHandler event_handler(spISimpleCOMClass);

	BSTR bstr = ::SysAllocString(L"Hello World");

	if (bstr)
	{
		spISimpleCOMClass->TestMethod01(bstr);

		::SysFreeString(bstr);
		bstr = NULL;
	}
}

int main()
{
	::CoInitialize(NULL);

	DoTest();

	::CoUninitialize();

    return 0;
}

