

/* this ALWAYS GENERATED file contains the IIDs and CLSIDs */

/* link this file in with the server and any clients */


 /* File created by MIDL compiler version 8.00.0603 */
/* at Sat Feb 04 01:55:39 2017
 */
/* Compiler settings for SimpleATLCOMServer.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 8.00.0603 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


#ifdef __cplusplus
extern "C"{
#endif 


#include <rpc.h>
#include <rpcndr.h>

#ifdef _MIDL_USE_GUIDDEF_

#ifndef INITGUID
#define INITGUID
#include <guiddef.h>
#undef INITGUID
#else
#include <guiddef.h>
#endif

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        DEFINE_GUID(name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8)

#else // !_MIDL_USE_GUIDDEF_

#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        const type name = {l,w1,w2,{b1,b2,b3,b4,b5,b6,b7,b8}}

#endif !_MIDL_USE_GUIDDEF_

MIDL_DEFINE_GUID(IID, IID_ISimpleCOMClass,0x4C1AE3E8,0x736E,0x4750,0x9D,0x08,0x48,0xCD,0xC3,0x3E,0x66,0xFA);


MIDL_DEFINE_GUID(IID, LIBID_SimpleATLCOMServerLib,0x8A32BF84,0x3743,0x4AE5,0xA7,0x91,0x62,0x3F,0x17,0xC6,0xE8,0x04);


MIDL_DEFINE_GUID(IID, DIID__ISimpleCOMClassEvents,0x60FD53D5,0x2D3E,0x4BCC,0x96,0xE6,0x48,0x4F,0x8D,0x8A,0x51,0x19);


MIDL_DEFINE_GUID(CLSID, CLSID_SimpleCOMClass,0x68226D2E,0x8EE4,0x4B42,0x9B,0x39,0x2D,0x4E,0xD9,0xD5,0x78,0xDD);

#undef MIDL_DEFINE_GUID

#ifdef __cplusplus
}
#endif



