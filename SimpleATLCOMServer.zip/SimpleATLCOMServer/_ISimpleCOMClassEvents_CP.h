#pragma once

template<class T>
class CProxy_ISimpleCOMClassEvents :
	public ATL::IConnectionPointImpl<T, &__uuidof(_ISimpleCOMClassEvents)>
{
public:
	HRESULT Fire_TestEvent01(BSTR strParam)
	{
		HRESULT hr = S_OK;
		T * pThis = static_cast<T *>(this);
		int cConnections = m_vec.GetSize();

		//MessageBox(NULL, "Stage 1", "Event", MB_OK);

		for (int iConnection = 0; iConnection < cConnections; iConnection++)
		{
			//MessageBox(NULL, "Stage 2", "Event", MB_OK);

			pThis->Lock();
			CComPtr<IUnknown> punkConnection = m_vec.GetAt(iConnection);
			pThis->Unlock();

			IDispatch * pConnection = static_cast<IDispatch *>(punkConnection.p);

			if (pConnection)
			{
				CComVariant avarParams[1];
				avarParams[0] = strParam;
				avarParams[0].vt = VT_BSTR;
				CComVariant varResult;

				//MessageBox(NULL, "Stage 3", "Event", MB_OK);

				DISPPARAMS params = { avarParams, NULL, 1, 0 };
				hr = pConnection->Invoke(1, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &params, &varResult, NULL, NULL);

				//MessageBox(NULL, "Stage 4", "Event", MB_OK);
			}
		}
		return hr;
	}
};

