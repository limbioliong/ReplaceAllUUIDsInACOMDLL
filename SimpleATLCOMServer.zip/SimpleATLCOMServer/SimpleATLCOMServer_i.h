

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.00.0603 */
/* at Sat Feb 04 01:55:39 2017
 */
/* Compiler settings for SimpleATLCOMServer.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 8.00.0603 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __SimpleATLCOMServer_i_h__
#define __SimpleATLCOMServer_i_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __ISimpleCOMClass_FWD_DEFINED__
#define __ISimpleCOMClass_FWD_DEFINED__
typedef interface ISimpleCOMClass ISimpleCOMClass;

#endif 	/* __ISimpleCOMClass_FWD_DEFINED__ */


#ifndef ___ISimpleCOMClassEvents_FWD_DEFINED__
#define ___ISimpleCOMClassEvents_FWD_DEFINED__
typedef interface _ISimpleCOMClassEvents _ISimpleCOMClassEvents;

#endif 	/* ___ISimpleCOMClassEvents_FWD_DEFINED__ */


#ifndef __SimpleCOMClass_FWD_DEFINED__
#define __SimpleCOMClass_FWD_DEFINED__

#ifdef __cplusplus
typedef class SimpleCOMClass SimpleCOMClass;
#else
typedef struct SimpleCOMClass SimpleCOMClass;
#endif /* __cplusplus */

#endif 	/* __SimpleCOMClass_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __ISimpleCOMClass_INTERFACE_DEFINED__
#define __ISimpleCOMClass_INTERFACE_DEFINED__

/* interface ISimpleCOMClass */
/* [unique][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_ISimpleCOMClass;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("4C1AE3E8-736E-4750-9D08-48CDC33E66FA")
    ISimpleCOMClass : public IDispatch
    {
    public:
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE TestMethod01( 
            /* [in] */ BSTR strParam) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct ISimpleCOMClassVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISimpleCOMClass * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISimpleCOMClass * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISimpleCOMClass * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISimpleCOMClass * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISimpleCOMClass * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISimpleCOMClass * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISimpleCOMClass * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *TestMethod01 )( 
            ISimpleCOMClass * This,
            /* [in] */ BSTR strParam);
        
        END_INTERFACE
    } ISimpleCOMClassVtbl;

    interface ISimpleCOMClass
    {
        CONST_VTBL struct ISimpleCOMClassVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISimpleCOMClass_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define ISimpleCOMClass_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define ISimpleCOMClass_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define ISimpleCOMClass_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define ISimpleCOMClass_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define ISimpleCOMClass_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define ISimpleCOMClass_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define ISimpleCOMClass_TestMethod01(This,strParam)	\
    ( (This)->lpVtbl -> TestMethod01(This,strParam) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __ISimpleCOMClass_INTERFACE_DEFINED__ */



#ifndef __SimpleATLCOMServerLib_LIBRARY_DEFINED__
#define __SimpleATLCOMServerLib_LIBRARY_DEFINED__

/* library SimpleATLCOMServerLib */
/* [version][uuid] */ 


EXTERN_C const IID LIBID_SimpleATLCOMServerLib;

#ifndef ___ISimpleCOMClassEvents_DISPINTERFACE_DEFINED__
#define ___ISimpleCOMClassEvents_DISPINTERFACE_DEFINED__

/* dispinterface _ISimpleCOMClassEvents */
/* [uuid] */ 


EXTERN_C const IID DIID__ISimpleCOMClassEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("60FD53D5-2D3E-4BCC-96E6-484F8D8A5119")
    _ISimpleCOMClassEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _ISimpleCOMClassEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            _ISimpleCOMClassEvents * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            _ISimpleCOMClassEvents * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            _ISimpleCOMClassEvents * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            _ISimpleCOMClassEvents * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            _ISimpleCOMClassEvents * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            _ISimpleCOMClassEvents * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            _ISimpleCOMClassEvents * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        END_INTERFACE
    } _ISimpleCOMClassEventsVtbl;

    interface _ISimpleCOMClassEvents
    {
        CONST_VTBL struct _ISimpleCOMClassEventsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _ISimpleCOMClassEvents_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define _ISimpleCOMClassEvents_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define _ISimpleCOMClassEvents_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define _ISimpleCOMClassEvents_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define _ISimpleCOMClassEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define _ISimpleCOMClassEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define _ISimpleCOMClassEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___ISimpleCOMClassEvents_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_SimpleCOMClass;

#ifdef __cplusplus

class DECLSPEC_UUID("68226D2E-8EE4-4B42-9B39-2D4ED9D578DD")
SimpleCOMClass;
#endif
#endif /* __SimpleATLCOMServerLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long *, unsigned long            , BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserMarshal(  unsigned long *, unsigned char *, BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserUnmarshal(unsigned long *, unsigned char *, BSTR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long *, BSTR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


