// SimpleCOMClass.cpp : Implementation of CSimpleCOMClass

#include "stdafx.h"
#include "SimpleCOMClass.h"
#include <comutil.h>


// CSimpleCOMClass

STDMETHODIMP CSimpleCOMClass::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* const arr[] = 
	{
		&IID_ISimpleCOMClass
	};

	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}


STDMETHODIMP CSimpleCOMClass::TestMethod01(BSTR strParam)
{
	// TODO: Add your implementation code here
	_bstr_t _bst(strParam, true);
	LPCTSTR lpszParam = (LPCTSTR)_bst;

	MessageBox(NULL, lpszParam, "CSimpleCOMClass", MB_OK);

	Fire_TestEvent01(strParam);

	return S_OK;
}
