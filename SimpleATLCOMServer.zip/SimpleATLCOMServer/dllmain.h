// dllmain.h : Declaration of module class.

class CSimpleATLCOMServerModule : public ATL::CAtlDllModuleT< CSimpleATLCOMServerModule >
{
public :
	DECLARE_LIBID(LIBID_SimpleATLCOMServerLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_SIMPLEATLCOMSERVER, "{965B95D4-A88C-4DBE-9272-0A5191CEEF91}")
};

extern class CSimpleATLCOMServerModule _AtlModule;
